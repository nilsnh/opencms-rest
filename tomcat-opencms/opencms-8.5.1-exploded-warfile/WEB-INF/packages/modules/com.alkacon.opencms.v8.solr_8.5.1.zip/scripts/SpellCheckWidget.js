(function ($) {


AjaxSolr.SpellCheckWidget = AjaxSolr.AbstractSpellcheckWidget.extend({
  
});

})(jQuery);
