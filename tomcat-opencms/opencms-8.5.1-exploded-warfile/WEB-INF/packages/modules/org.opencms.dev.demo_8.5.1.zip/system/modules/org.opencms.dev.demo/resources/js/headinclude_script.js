function displayDate()
{
document.getElementById("dateText").innerHTML=Date();
}