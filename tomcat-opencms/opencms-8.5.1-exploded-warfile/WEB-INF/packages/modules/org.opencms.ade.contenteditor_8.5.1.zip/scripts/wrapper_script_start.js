// storing any present jquery instance
var __storedJqueryInstance=null;
if (typeof jQuery != 'undefined'){
    __storedJqueryInstance=jQuery;
};

