FCKLang.OcmsImageBtn			= "Insert/Edit image";
FCKLang.OcmsImageDlgTitle		= "Image Properties";
FCKLang.OcmsImageDlgTooltip		= "Insert/Edit image";

// Dialog tabs
FCKLang.DlgImgGalleryTab		= "Image Gallery";

// Detail info keys
FCKLang.DlgImgDetailType		= "Image type";
FCKLang.DlgImgDetailTypegif		= "GIF Image";
FCKLang.DlgImgDetailTypejpg		= "JPEG Image";
FCKLang.DlgImgDetailTypepng		= "PNG Image";
FCKLang.DlgImgDetailTypetif		= "TIFF Image";
FCKLang.DlgImgDetailTypebmp		= "Bitmap Image";
FCKLang.DlgImgDetailTypeNo		= "Unknown image type";

FCKLang.DlgImgAltText			= "Description / Alt-Text";
FCKLang.DlgImgSubtitle			= "Insert subtitle";
FCKLang.DlgBtnResetTitle		= "Reset Title";
FCKLang.DlgImgCopyrightText		= "Copyright Information";
FCKLang.DlgImgCopyright			= "Insert copyright information";
FCKLang.DlgBtnResetCopyright		= "Reset Copyright";

FCKLang.DlgImgLinkOriginal		= "Insert link to image in original format";

FCKLang.DlgImgImageBorder		= "Create image spacings";
FCKLang.DlgImgAlignNone			= "None";

// Image gallery keys
FCKLang.DlgImgInfoHeadline		= "Image information";
FCKLang.DlgImgInfoName			= "Name:";
FCKLang.DlgImgInfoTitle			= "Title:";
FCKLang.DlgImgInfoType			= "Type:";
FCKLang.DlgImgInfoDateCreated		= "Creation date:";
FCKLang.DlgImgInfoDateModified		= "Modification date:";
FCKLang.DlgImgInfoId			= "ID:";
FCKLang.DlgImgInfoFormat		= "Format:";
FCKLang.DlgImgInfoSize			= "Size:";

FCKLang.DlgImgNavBack			= "Back";
FCKLang.DlgImgNavNext			= "Next";

FCKLang.DlgImgStateNew			= "This image is new and not yet publicly available.";
FCKLang.DlgImgStateChanged		= "The changes on this image are not yet published.";

FCKLang.DlgImgAjaxWait			= "Please wait...";