// german localization of editor dialogs
var lang = {
  search : "Suchen:",
  hint : "Benutzen Sie die /re/ Syntax f&uuml;r die Suche mit regul&auml;ren Ausdr&uuml;cken",
  replace : "Ersetzen:",
  replacewith : "Mit:",
  replaceconfirm : "Ersetzen?",
  replaceyes : "Ja",
  replaceno : "Nein",
  replacestop : "Stop"
};