// english localization of editor dialogs
var lang = {
  search : "Search:",
  hint : "Use /re/ syntax for regexp search",
  replace : "Replace:",
  replacewith : "With:",
  replaceconfirm : "Replace?",
  replaceyes : "Yes",
  replaceno : "No",
  replacestop : "Stop",
  fontsize: "--Font size--"
};